# AI Agent Instructions for Web Programming Project

## Project Overview
This is a web programming practice project that demonstrates basic HTML concepts and structures. The project consists of simple web pages showcasing various HTML elements and their usage.

## Project Structure
```
/
├── index.html        # Main page with HTML element examples
├── hal2.html         # Secondary page demonstrating image usage
└── assets/          # Image assets directory
    ├── *.png        # Various PNG images
    └── thumbnail/   # Thumbnail versions of images
```

## Key Conventions and Patterns

### HTML Structure
- Pages use standard HTML5 doctype declaration
- Basic HTML structure with `head` and `body` sections
- UTF-8 character encoding used when specified

### Image Handling
- Images are stored in the `assets/` directory
- Thumbnails are stored in `assets/thumbnail/`
- Images use relative paths (e.g., `assets/anggora.png`)
- Always include `alt` attributes for accessibility
- Width specifications use `px` units (e.g., `width="200px"`)

### Navigation
- Pages are linked using relative paths (e.g., `href="hal2.html"`)
- Navigation is simple and direct between pages

### Tables
- Tables use the `border` attribute for visibility
- Table structure follows `table > tr > th/td` pattern
- Headers use `th` elements for proper semantic markup

### Lists
- Unordered lists use `type="square"` for custom bullets
- Ordered lists use Roman numerals (`type="I"`)
- List items are kept simple and consistent

## Common Development Tasks
The project is pure HTML, requiring no build process. Files can be directly edited and viewed in a browser.

## Testing and Validation
- Ensure all image paths are correct and images load properly
- Validate proper table structure
- Check list formatting and numbering
- Verify all links work correctly
- Test responsiveness of images with specified widths

## Best Practices
1. Maintain consistent indentation in HTML files
2. Use semantic HTML elements appropriately
3. Keep image paths relative to the project root
4. Include appropriate alt text for all images
5. Maintain consistent table and list structures

## Project Goals
This project serves as a learning environment for basic HTML concepts including:
- Text formatting
- Image embedding
- Table creation
- List structures
- Basic navigation
- HTML semantic elements